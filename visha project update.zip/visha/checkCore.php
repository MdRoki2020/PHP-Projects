<?php
$connect = mysqli_connect('localhost', 'root', '', 'worldpas_vishasearch');

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_REQUEST['submit'])) {
    // Use mysqli_real_escape_string to sanitize input
    $password = mysqli_real_escape_string($connect, $_REQUEST['password']);
    $id = mysqli_real_escape_string($connect, $_REQUEST['id']);
    
    // Avoid echoing sensitive information like passwords
    // echo $password;
    // echo $id;
    
    $selectQuery = "SELECT * FROM `forms_data` WHERE passportId='$password' AND id='$id'";
    
    $runQuery = mysqli_query($connect, $selectQuery);
    
    // Check if the query was successful
    if ($runQuery) {
        $chakeCount = mysqli_num_rows($runQuery);
        
        // Check if a single row was found
        if ($chakeCount === 1) {
            setcookie("forms_dataUserId", $password, time() + (86400 * 7));
            header("location:userProfile.php");
            exit; // Stop script execution after redirection
        } else {
            header('location:check.php?wrongUser');
            exit; // Stop script execution after redirection
        }
    } else {
        // Handle query error
        echo "Query error: " . mysqli_error($connect);
        exit;
    }
}

// Close the database connection after use
mysqli_close($connect);
?>
