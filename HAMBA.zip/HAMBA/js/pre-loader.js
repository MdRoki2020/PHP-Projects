var load_page=document.getElementById('loading-page');

function invisible(){
    load_page.style.display='none';
}