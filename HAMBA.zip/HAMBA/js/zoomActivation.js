//Zoom Activation

$("#zoom_01").elevateZoom();