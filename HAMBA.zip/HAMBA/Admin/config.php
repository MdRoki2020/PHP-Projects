<?php

$connect=mysqli_connect('localhost','root','','RoomFinder');

if($connect==false){
    echo 'Database Connection Not Established';
}

?>


<?php
//
//$connect=mysqli_connect('localhost','rsrokiin_roomfinderuser','AaBbCc2580!!@@','rsrokiin_roomfinder');
//
//if($connect==false){
//    echo 'Database Connection Not Established';
//}
//
//?>
