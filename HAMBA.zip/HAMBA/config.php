<?php
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'RoomFinder';

// Create a connection
$connect = mysqli_connect($hostname, $username, $password, $database);

// Check connection
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
} else {
    echo "Connected successfully!";
}

// Close the connection
mysqli_close($connect);
?>
