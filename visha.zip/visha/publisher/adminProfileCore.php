<?php
$connect = mysqli_connect('localhost', 'root', '', 'vishasearch');

if (isset($_POST["update"])) {
    // Validate and sanitize input data
    $email = mysqli_real_escape_string($connect, $_POST["email"]);
    $password = mysqli_real_escape_string($connect, $_POST["password"]);

    // Use password_hash() to securely hash passwords
    // $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $updateQuery = "UPDATE `userdetails` SET `email`='$email', `password`='$password' WHERE `id`=1";
    $runQuery = mysqli_query($connect, $updateQuery);

    if ($runQuery) {
        header("location: adminprofiletrue.php?right");
        exit; // Stop script execution after redirection
    }
}

// Close the database connection after use
mysqli_close($connect);
?>
