<?php

$connect=mysqli_connect('localhost','root','','HAMBA');

if($connect==false){
    echo 'Database Connection Not Established';
}

?>