-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2023 at 06:47 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vishasearch`
--

-- --------------------------------------------------------

--
-- Table structure for table `extraphotos`
--

CREATE TABLE `extraphotos` (
  `id` int(11) NOT NULL,
  `passportId` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `extraphotos`
--

INSERT INTO `extraphotos` (`id`, `passportId`, `photo`, `date`) VALUES
(7, 'EK0378603', '1212810817.png', '2023-12-05 11:33:59'),
(8, 'EK0378603', '1259699849.png', '2023-12-05 11:34:22');

-- --------------------------------------------------------

--
-- Table structure for table `extravishaphotos`
--

CREATE TABLE `extravishaphotos` (
  `id` int(11) NOT NULL,
  `passportId` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `extravishaphotos`
--

INSERT INTO `extravishaphotos` (`id`, `passportId`, `photo`, `date`) VALUES
(3, 'ed2fed523fw', '975620091.jpg', '2023-12-05'),
(4, 'ed2fed523fw', '480194057.jpg', '2023-12-05'),
(5, 'ed2fed523fw', '1239522231.png', '2023-12-05');

-- --------------------------------------------------------

--
-- Table structure for table `forms_data`
--

CREATE TABLE `forms_data` (
  `id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `passportId` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `forms_data`
--

INSERT INTO `forms_data` (`id`, `category`, `name`, `passportId`, `photo`, `date`) VALUES
(9, 'forms', 'Ali Babar', 'EK0378603', '1909656173.jpg', '2023-12-05 11:33:15');

-- --------------------------------------------------------

--
-- Table structure for table `userdetails`
--

CREATE TABLE `userdetails` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userdetails`
--

INSERT INTO `userdetails` (`id`, `email`, `password`) VALUES
(1, 'shakil@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `visha_data`
--

CREATE TABLE `visha_data` (
  `id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `passportId` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `visha_data`
--

INSERT INTO `visha_data` (`id`, `category`, `name`, `passportId`, `photo`, `date`) VALUES
(5, 'visha', 'MD.Rakibul Islam', 'ed2fed523fw', '41201650.png', '2023-12-05 11:34:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `extraphotos`
--
ALTER TABLE `extraphotos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `extravishaphotos`
--
ALTER TABLE `extravishaphotos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forms_data`
--
ALTER TABLE `forms_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userdetails`
--
ALTER TABLE `userdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visha_data`
--
ALTER TABLE `visha_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `extraphotos`
--
ALTER TABLE `extraphotos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `extravishaphotos`
--
ALTER TABLE `extravishaphotos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `forms_data`
--
ALTER TABLE `forms_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `userdetails`
--
ALTER TABLE `userdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `visha_data`
--
ALTER TABLE `visha_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
