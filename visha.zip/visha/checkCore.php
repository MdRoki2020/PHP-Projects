<?php
$connect = mysqli_connect('localhost', 'root', '', 'vishasearch');

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

$password = $_REQUEST['password'];
$id = $_REQUEST['id'];

// Use prepared statements to prevent SQL injection
$selectQuery = "SELECT * FROM `forms_data` WHERE passportId = ? AND id = ?";
$stmt = mysqli_prepare($connect, $selectQuery);
mysqli_stmt_bind_param($stmt, 'ss', $password, $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if ($result && mysqli_num_rows($result) === 1) {
    setcookie("forms_dataUserId", $password, time() + (86400 * 7));
    header("location: userProfile.php");
} else {
    header('location: check.php?wrongUser');
}

// Close the database connection after use
mysqli_close($connect);
?>
