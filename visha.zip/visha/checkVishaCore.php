<?php
$connect = mysqli_connect('localhost', 'root', '', 'vishasearch');

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

$password = $_REQUEST['password'];
$id = $_REQUEST['id'];

// Use prepared statements to prevent SQL injection
$selectQuery = "SELECT * FROM `visha_data` WHERE passportId = ? AND id = ?";
$stmt = mysqli_prepare($connect, $selectQuery);
mysqli_stmt_bind_param($stmt, 'ss', $password, $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if ($result && mysqli_num_rows($result) === 1) {
    setcookie("visha_dataUserId", $password, time() + (86400 * 7));
    header("location: userVishaProfile.php");
} else {
    header('location: checkVisha.php?wrongUserVisha');
}

// Close the database connection after use
mysqli_close($connect);
?>
